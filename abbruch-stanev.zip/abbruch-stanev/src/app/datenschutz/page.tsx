import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Datenschutzerklärung | Abbruch Stanev Leipzig",
  robots: { index: false, follow: false },
};

export default function Datenschutz() {
  return (
    <div className="min-h-screen bg-[#111111] text-white">
      <div className="max-w-3xl mx-auto px-4 py-20">
        <Link
          href="/"
          className="inline-flex items-center gap-2 text-[#f97316] text-sm mb-12 hover:text-white transition-colors uppercase tracking-wider"
        >
          ← Zurück
        </Link>

        <h1 className="font-display text-5xl text-white mb-2">DATENSCHUTZ</h1>
        <div className="w-16 h-1 bg-[#f97316] mb-10" />

        <div className="space-y-8 text-[#888888] text-sm leading-relaxed">
          <section>
            <h2 className="text-white font-medium text-lg mb-3 uppercase tracking-wide">
              1. Datenschutz auf einen Blick
            </h2>
            <p>
              Die folgenden Hinweise geben einen einfachen Überblick darüber, was mit
              Ihren personenbezogenen Daten passiert, wenn Sie diese Website besuchen.
              Personenbezogene Daten sind alle Daten, mit denen Sie persönlich identifiziert
              werden können.
            </p>
          </section>

          <section>
            <h2 className="text-white font-medium text-lg mb-3 uppercase tracking-wide">
              2. Verantwortlicher
            </h2>
            <p>
              Verantwortlich für die Datenverarbeitung auf dieser Website ist:<br /><br />
              Abbruch Stanev<br />
              Leipzig, Sachsen<br />
              Telefon: 0151 66762975<br />
              E-Mail: info@abbruch-stanev.de
            </p>
          </section>

          <section>
            <h2 className="text-white font-medium text-lg mb-3 uppercase tracking-wide">
              3. Datenerfassung auf dieser Website
            </h2>
            <h3 className="text-white text-sm font-medium mb-2">Kontaktformular</h3>
            <p>
              Wenn Sie uns per Kontaktformular Anfragen zukommen lassen, werden Ihre
              Angaben aus dem Anfrageformular inklusive der von Ihnen dort angegebenen
              Kontaktdaten zwecks Bearbeitung der Anfrage und für den Fall von Anschlussfragen
              bei uns gespeichert. Diese Daten geben wir nicht ohne Ihre Einwilligung weiter.
              Rechtsgrundlage: Art. 6 Abs. 1 lit. b DSGVO.
            </p>
          </section>

          <section>
            <h2 className="text-white font-medium text-lg mb-3 uppercase tracking-wide">
              4. Google Maps
            </h2>
            <p>
              Diese Seite nutzt über eine API den Kartendienst Google Maps. Anbieter ist die
              Google Ireland Limited. Zur Nutzung der Funktionen von Google Maps ist es
              notwendig, Ihre IP-Adresse zu speichern. Diese Informationen werden in der
              Regel an einen Server von Google in den USA übertragen und dort gespeichert.
              Rechtsgrundlage: Art. 6 Abs. 1 lit. f DSGVO.
            </p>
          </section>

          <section>
            <h2 className="text-white font-medium text-lg mb-3 uppercase tracking-wide">
              5. Ihre Rechte
            </h2>
            <p>
              Sie haben jederzeit das Recht auf unentgeltliche Auskunft über Ihre
              gespeicherten personenbezogenen Daten, deren Herkunft und Empfänger und den
              Zweck der Datenverarbeitung sowie ein Recht auf Berichtigung, Sperrung oder
              Löschung dieser Daten. Hierzu sowie zu weiteren Fragen zum Thema
              Datenschutz können Sie sich jederzeit unter der im Impressum angegebenen
              Adresse an uns wenden.
            </p>
          </section>

          <section>
            <h2 className="text-white font-medium text-lg mb-3 uppercase tracking-wide">
              6. Cookies
            </h2>
            <p>
              Diese Website setzt keine Tracking-Cookies ein. Es werden ausschließlich
              technisch notwendige Cookies verwendet, die für den Betrieb der Website
              erforderlich sind.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
