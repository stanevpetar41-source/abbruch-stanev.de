import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Impressum | Abbruch Stanev Leipzig",
  robots: { index: false, follow: false },
};

export default function Impressum() {
  return (
    <div className="min-h-screen bg-[#111111] text-white">
      <div className="max-w-3xl mx-auto px-4 py-20">
        <Link
          href="/"
          className="inline-flex items-center gap-2 text-[#f97316] text-sm mb-12 hover:text-white transition-colors uppercase tracking-wider"
        >
          ← Zurück
        </Link>

        <h1 className="font-display text-5xl text-white mb-2">IMPRESSUM</h1>
        <div className="w-16 h-1 bg-[#f97316] mb-10" />

        <div className="space-y-8 text-[#888888] text-sm leading-relaxed">
          <section>
            <h2 className="text-white font-medium text-lg mb-3 uppercase tracking-wide">
              Angaben gemäß § 5 TMG
            </h2>
            <p>
              Abbruch Stanev<br />
              Leipzig, Sachsen<br />
              Deutschland
            </p>
          </section>

          <section>
            <h2 className="text-white font-medium text-lg mb-3 uppercase tracking-wide">Kontakt</h2>
            <p>
              Telefon:{" "}
              <a href="tel:015166762975" className="text-[#f97316] hover:underline">
                0151 66762975
              </a>
              <br />
              E-Mail: info@abbruch-stanev.de
            </p>
          </section>

          <section>
            <h2 className="text-white font-medium text-lg mb-3 uppercase tracking-wide">
              Haftung für Inhalte
            </h2>
            <p>
              Als Diensteanbieter sind wir gemäß § 7 Abs.1 TMG für eigene Inhalte auf
              diesen Seiten nach den allgemeinen Gesetzen verantwortlich. Nach §§ 8 bis 10
              TMG sind wir als Diensteanbieter jedoch nicht verpflichtet, übermittelte oder
              gespeicherte fremde Informationen zu überwachen oder nach Umständen zu
              forschen, die auf eine rechtswidrige Tätigkeit hinweisen.
            </p>
          </section>

          <section>
            <h2 className="text-white font-medium text-lg mb-3 uppercase tracking-wide">
              Haftung für Links
            </h2>
            <p>
              Unser Angebot enthält Links zu externen Websites Dritter, auf deren Inhalte
              wir keinen Einfluss haben. Deshalb können wir für diese fremden Inhalte auch
              keine Gewähr übernehmen.
            </p>
          </section>

          <section>
            <h2 className="text-white font-medium text-lg mb-3 uppercase tracking-wide">
              Urheberrecht
            </h2>
            <p>
              Die durch die Seitenbetreiber erstellten Inhalte und Werke auf diesen Seiten
              unterliegen dem deutschen Urheberrecht.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
